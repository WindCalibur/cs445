function [ sum ] = M( i, j)
    if ((i == 0) && (j == 0)) 
        sum = 1;
    elseif ((i == 0) && (j ~= 0))
        sum = 0;
    elseif ((i ~= 0) && (j == 0))
        sum = 0;
    else 
        sum = GY(i-1, j-1) + GX(i-1, j-1) + M(i-1, j-1);
    end
end

