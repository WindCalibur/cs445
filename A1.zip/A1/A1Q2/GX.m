function [ sum ] = GX( i, j)
    if ((i == 0) && (j == 0)) 
        sum = 0;
    elseif ((i == 0) && (j ~= 0));
        sum = 0;
    elseif ((i ~= 0) && (j == 0));
        sum = 1;
    else 
        sum = GX(i-1, j) + M(i-1, j);
    end
end

