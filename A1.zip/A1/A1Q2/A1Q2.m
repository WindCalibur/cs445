function [ answer ] = A1Q2( n )
    answer = GY(n, n) + GX(n, n) + M(n, n);
end

