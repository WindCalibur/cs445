PAM = xlsread('PAM.xlsx');
PAM = PAM/10000;
PAM20 = PAM^20;
QPROB = xlsread('QPROB.xlsx');
RESULT = zeros(20);
for i = 1:20
   for j = 1:20
       RESULT(i,j) = round(10 * log10(PAM20(i,j) / QPROB(j)));
   end
end