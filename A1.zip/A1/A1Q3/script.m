d=10;
e=5;
[num,txt,raw] = xlsread('BLOSOM.xlsx');
FASTAData = fastaread('data.fasta');
FSize = size(FASTAData);
FSize = FSize(1);
firstString = fileread('unknown.txt');
firstString = cellstr(firstString);
firstString = firstString{1};
blosom = num;
blosomLegend = cell2mat(txt(1,2:end));
blosomLegend = [blosomLegend, 'U'];
% Add extra column for U
cIndex = strfind(blosomLegend,'C');
blosom2 = zeros(26,26);
blosom2(1:25,1:25) = blosom;
blosom2(26,1:25) = blosom(cIndex, :);
blosom2(1:25,26) = blosom(:, cIndex);
blosom2(26,26) = blosom(cIndex, cIndex);
blosom = blosom2;

resultIndex = [];
resultName = {};
resultScore = [];

for k = 1:FSize
    fData = FASTAData(k);
    secondString = getfield(fData, 'Sequence');
    header = getfield(fData, 'Header');
    
    %Find name
    idx = strfind( header, '|');
    idx = idx(2) + 1;
    idxSpace = strfind( header, ' ');
    idxSpace = idxSpace(1)-1;
    geneName = header(idx:idxSpace);
    
    %Index
    index = k + 1;
    
    %Score Compuation
    score = A1Q3(firstString,secondString,d,e,blosom,blosomLegend)
    
    %Finding 3 smallest scores
    if (k <= 3) 
        resultIndex(k) = index;
        resultName{k} = geneName;
        resultScore(k) = score;
    elseif (score > min(resultScore))
        [V,j] =  min(resultScore);
        resultIndex(j) = index;
        resultName{j} = geneName;
        resultScore(j) = score;
    end
    
    % Didn't bother sorting it out since we only have 3 results
    
end

